-------------------------------------------------------
Blake Rieschick
2829512
Class: EECS 560 
Lab Number: 01
Last Update: September 4, 2019
-------------------------------------------------------
To run this program:
 -run make in this directory.
 -run ./DoubleLinkedList <inputFile>
 -run commands
-------------------------------------------------------

